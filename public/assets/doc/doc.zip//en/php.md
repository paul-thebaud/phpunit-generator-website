### PHP code

 Here is an example of using PhpUnitGen in a PHP script.

```php 

<?php

use PhpUnitGen\Configuration\BaseConfig;
use PhpUnitGen\Container\ContainerFactory;
use PhpUnitGen\Executor\ExecutorInterface\ExecutorInterface;

// Require your composer autoload
require 'vendor/autoload.php';

// Create the config
$config = new BaseConfig([ /* ... some options ... */ ]);

// Create the dependency container of PhpUnitGen
$container = (new ContainerFactory())->invoke($config);

$myTestClass = 'MyClassTest';
$myCode = "<?php class MyClass { /* ... some PHP code ... */ }";

// Execute PhpUnitGen on your code to get the tests file content
$myUnitTestsSkeleton = $container->get(ExecutorInterface::class)->invoke($myCode, $myTestClass);

// Display the created tests skeletons on output
echo $myUnitTestsSkeleton;

```  
##### Notice

`new BaseConfig()` or `$container->get(ExecutorInterface::class)->invoke($myCode, $myTestClass)` can throw PHP exception if the config or if the code to parse is invalid.