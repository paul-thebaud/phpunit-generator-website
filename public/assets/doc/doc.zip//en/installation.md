### Installation

 Best way to install PhpUnitGen is through _Composer_. It will allow you to get update easily.   
 _Composer_ is the package manager for PHP project.

```bash 

$ composer require --dev paulthebaud/phpunit-generator ^2.0

```  
 The `--dev` option is used to install the package only in development environment.   
 PhpUnitGen use _PHP 7.1_, but is also compatible (and tested with _Travis_) with _PHP 7.2_.