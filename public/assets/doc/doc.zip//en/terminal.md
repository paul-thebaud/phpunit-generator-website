### Command line

 When you install this package, you can use the command line to generate your unit tests skeleton. Use this command in project root directory.

```bash 

$ php ./vendor/bin/phpunitgen

```  
 For this command, you will need a configuration file written in `YAML`, `JSON` or `PHP`.

- `YAML` example is available [here](https://github.com/paul-thebaud/phpunit-generator/blob/master/examples/phpunitgen.config.yml).
- `JSON` example is available [here](https://github.com/paul-thebaud/phpunit-generator/blob/master/examples/phpunitgen.config.json).
- `PHP` example is available [here](https://github.com/paul-thebaud/phpunit-generator/blob/master/examples/phpunitgen.config.php).

 By default, PhpUnitGen search for a configuration file named `phpunitgen.yml` at the project root.

 But if you want to use a **custom configuration path**, you can use an option:

```bash 

$ php ./vendor/bin/phpunitgen --config=my/custom/config.yml

$ php ./vendor/bin/phpunitgen -c=my/custom/config.yml

```  
 Use PhpUnitGen **on one file** only (use of `file` option need a source and a target):

```bash 

$ php ./vendor/bin/phpunitgen --file source/file.php target/file.php

$ php ./vendor/bin/phpunitgen -f source/file.php target/file.php

```  
 Use PhpUnitGen **on one directory** only (use of `dir` option need a source and a target):

```bash 

$ php ./vendor/bin/phpunitgen --dir source/dir target/dir

$ php ./vendor/bin/phpunitgen -d source/dir target/dir

```  
 Use PhpUnitGen with [**the default configuration**](https://github.com/paul-thebaud/phpunit-generator/blob/master/config/default.phpunitgen.config.php) (use of default configuration need a source and a target):

```bash 

$ php ./vendor/bin/phpunitgen --default --file source/file.php target/file.php
$ php ./vendor/bin/phpunitgen --default --dir source/dir target/dir

$ php ./vendor/bin/phpunitgen -D -f source/file.php target/file.php
$ php ./vendor/bin/phpunitgen -D -d source/dir target/dir

```  
##### Notice

- If you use the `default` option with the `config` option, configuration will be ignored and default configuration will be used.
- If you use the `default` option, and you don't provide the `dir` or the `file` option, PhpUnitGen will consider that source and target paths are directories.
- As PhpUnitGen use the Symfony Console package, you can combine multiple option together: `$ php ./vendor/bin/phpunitgen -fc my/custom/config.yml source/file.php target/file.php` will parse one file with your custom configuration.
 
#### Configuration

A configuration file needs the following parameters:

- **overwrite** \[_boolean_\]: Set _true_ if you want to erase old files with the new ones.
- **backup** \[_boolean_\]: Set _true_ if you want to backup old files before erase them when `overwrite` is set to _true_. Backup files while be named as following: `your_file.php.bak`
- **interface** \[_boolean_\]: Set _true_ if you want to generate unit tests skeletons for interface too.
- **private** \[_boolean_\]: Set _true_ if you want to generate unit tests skeletons for private / protected methods too.
- **auto** \[_boolean_\]: Set _true_ if you want to automatically generate `getter` / `setter` unit tests, and class or trait instantiation.
- **ignore** \[_boolean_\]: Set _true_ if you want to ignore errors that are not fatal.
- **exclude** \[_string_ or _null_\]: A PHP regex to filter files that have not to be parsed. Set as _null_ if you do not want to use an exclude regex.
- **include** \[_string_ or _null_\]: A PHP regex to filter files that have to be parsed. Set as _null_ if you do not want to use an include regex.
- **dirs** \[_array_\]: An array of `source: target` directories. PhpUnitGen will parse each files in your source directory (an array key) and put the generated unit tests skeletons in your target directory (an array value). It will also parse sub-directories. _null_ if you have no directory to parse.
- **files** \[_array_\]: An array of `source: target` files. PhpUnitGen will parse each files in your source file (an array key) and put the generated unit tests skeletons in your target file (an array value). _null_ if you have no file to parse.