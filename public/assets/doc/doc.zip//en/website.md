### Web application

 PhpUnitGen can be used **online**, because it parse the PHP code instead of using PHP Reflections.   
   
 Like many other tools, it **can be configure** in it operation or it design.   
 **Thanks to the configuration button** - in top right corner when you are in the application - you can change those parameters:

- **Editor height**: allow to change the PHP editor height.
- **Theme**: allow to change the application colors (in addition, there are surprises when you use the application 🦄).
- **Automatic generation**: allow to automatically generate unit tests for getters / setters methods, or instantiate classes or traits.
- **Private / protected methods parsing**: allow to activate / disable the skeletons generation for private or protected methods.
- **Interface parsing**: allow to activate / disable the skeleton generation for PHP interface.
- **Generated tests PHPDoc**: allow to manage a list of _PHPDoc_ annotations (`@author` for example) that will be added to the tests class header.

##### Notice

 This configuration will be **automatically saved** each time it is updated, directly in your browser storage. It is possible to **reset it with the "reset" button**, in the bottom left corner of the configuration page.

   
 The web application can be used with two solutions:

- You can **import a PHP file**.
- You can use the **PHP code editor** (remember that you can give a **name to the generated class**, in the **field above the editor**).

  
 Finally, when you are **on this documentation**, you can click on **the bottom right button** to go on the **PhpUnitGen application**.