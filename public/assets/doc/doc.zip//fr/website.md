### Application web

 PhpUnitGen est utilisable **en ligne**, car il analyse le code PHP plutôt que d'utiliser les Reflections PHP.   
   
 Comme de nombreux outils, il est **configurable** dans son fonctionnement ou son design.   
 **Grâce au bouton de configuration** - en haut à droite lorsque vous êtes sur l'application - vous pouvez modifier ces paramètres :

- **Taille de l'éditeur** : permet de régler la hauteur de l'éditeur de code PHP.
- **Thème** : permet de changer les couleurs de l'application (en plus il y a des surprises quand vous utilisez l'application 🦄).
- **Generation automatique** : permet de générer automatiquement les tests unitaires des méthodes getters / setters, ou l'instanciation des classes ou traits.
- **Analyse des méthodes privées / protégées** : permet d'activer ou de désactiver la génération de squelettes pour les méthodes privées ou protégées.
- **Analyse des interfaces** : permet d'activer ou de désactiver la génération de squelettes pour les interfaces PHP.
- **PHPDoc des tests générés** : permet de gérer une liste des annotations _PHPDoc_ (`@author` par exemple) qui se trouveront dans l'entête de la classe de test.

##### Note

 Cette configuration sera **automatiquement sauvegarder** à chaque modification, directement dans le **stockage de votre navigateur**. Il est possible de la **réinitialiser avec le bouton "reset"**, en bas à gauche de la page de configuration.

   
 L'application web peut ensuite être utilisé de deux manières différentes :

- Soit vous **importez un fichier PHP**.
- Soit vous utilisez l'**éditeur de code PHP** à votre disposition (n'oubliez pas que vous pouvez founir le **nom qu'aura la classe générée**, dans le **champs au dessus de l'éditeur**).

  
 Enfin, lorsque vous êtes **sur cette documentation**, vous pouvez juste cliquez sur le **bouton en bas à droite** pour aller sur l'**application PhpUnitGen**.