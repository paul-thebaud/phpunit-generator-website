### Installation

 La meilleure façon d'installer PhpUnitGen est via _Composer_. Cela permettra d'effectuer facilement les mises à jour.   
 _Composer_ est le gestionnaire de package pour les projets PHP.

```bash 

$ composer require --dev paulthebaud/phpunit-generator ^2.0

```  
 L'option `--dev` est utilisé pour installer le package uniquement dans un environnement de développement.   
 PhpUnitGen utilise _PHP 7.1_, mais est aussi compatible (et testé avec _Travis_) avec _PHP 7.2_.