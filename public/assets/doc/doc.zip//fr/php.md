### Code PHP

 Voici un exemple d'utilisation de PhpUnitGen dans un script PHP.

```php 

<?php

use PhpUnitGen\Configuration\BaseConfig;
use PhpUnitGen\Container\ContainerFactory;
use PhpUnitGen\Executor\ExecutorInterface\ExecutorInterface;

// Importer l'autoload Composer
require 'vendor/autoload.php';

// Créer la configuration
$config = new BaseConfig([ /* ... des options ... */ ]);

// Créer le conteneur de dépendances
$container = (new ContainerFactory())->invoke($config);

$myTestClass = 'MyClassTest';
$myCode = "<?php class MyClass { /* ... du code PHP ... */ }";

// Exécuter PhpUnitGen sur le code et enregistrer les résultats
$myUnitTestsSkeleton = $container->get(ExecutorInterface::class)->invoke($myCode, $myTestClass);

// Afficher les résultats
echo $myUnitTestsSkeleton;

```  
##### Note

`new BaseConfig()` ou `$container->get(ExecutorInterface::class)->invoke($myCode, $myTestClass)` sont suceptibles de lever des exceptions PHP, si la configuration fournie est invalide par exemple.