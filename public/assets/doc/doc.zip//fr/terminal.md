### Ligne de commande

 Quand vous installer le package _Composer_, vous pouvez utiliser PhpUnitGen en ligne de commande. Il faut vous place à la racine de votre projet _Composer_.

```bash 

$ php ./vendor/bin/phpunitgen

```  
 Pour cette commande, vous aurez besoin d'un fichier de configuration écrit en `YAML`, `JSON` ou `PHP`.

- L'example `YAML` se trouve ici [here](https://github.com/paul-thebaud/phpunit-generator/blob/master/examples/phpunitgen.config.yml).
- L'example `JSON` se trouve ici [here](https://github.com/paul-thebaud/phpunit-generator/blob/master/examples/phpunitgen.config.json).
- L'example `PHP` se trouve ici [here](https://github.com/paul-thebaud/phpunit-generator/blob/master/examples/phpunitgen.config.php).

 Par défaut (sans option), PhpUnitGen cherchera un fichier de configuration nommé `phpunitgen.yml` à la racine du projet.

 Mais si vous souhaitez utiliser une **configuration personnalisé**, vous pouvez utiliser une option :

```bash 

$ php ./vendor/bin/phpunitgen --config=my/custom/config.yml

$ php ./vendor/bin/phpunitgen -c=my/custom/config.yml

```  
 Pour utiliser PhpUnitGen sur **un seul fichier** (l'utilisation de l'option `file` aura besoin d'une source et d'une cible étant des fichiers) :

```bash 

$ php ./vendor/bin/phpunitgen --file source/file.php target/file.php

$ php ./vendor/bin/phpunitgen -f source/file.php target/file.php

```  
 Pour utiliser PhpUnitGen sur **un seul dossier** (l'utilisation de l'option `dir` aura besoin d'une source et d'une cible étant des dossiers) :

```bash 

$ php ./vendor/bin/phpunitgen --dir source/dir target/dir

$ php ./vendor/bin/phpunitgen -d source/dir target/dir

```  
 Pour utiliser PhpUnitGen avec [**la configuration par défaut**](https://github.com/paul-thebaud/phpunit-generator/blob/master/config/default.phpunitgen.config.php) (l'utilisation de l'option `default` aura besoin d'une source et d'une cible):

```bash 

$ php ./vendor/bin/phpunitgen --default --file source/file.php target/file.php
$ php ./vendor/bin/phpunitgen --default --dir source/dir target/dir

$ php ./vendor/bin/phpunitgen -D -f source/file.php target/file.php
$ php ./vendor/bin/phpunitgen -D -d source/dir target/dir

```  
##### Note

- Si vous utilisez l'option `default` avec l'option `config`, la configuration sera ignorée et PhpUnitGen utilisera la configuration par défaut.
- Si vous utilisez l'option `default`, et que vous ne fournissez pas d'option `dir` ou `file`, PhpUnitGen considèrera que les source et cible sont des dossiers.
- Etant donné que PhpUnitGen utilise le package de la Console Symfony, vous pouvez combiner plusieurs raccourcis d'options ensemble : `$ php ./vendor/bin/phpunitgen -fc my/custom/config.yml source/file.php target/file.php` analysera un seul fichier avec la configuration personnalisée fournie.
 
#### Configuration

Un fichier de configuration aura besoin de tous les paramètres suivants :

- **overwrite** \[_boolean_\]: Utilisez la valeur _true_ si vous voulez que les fichiers qui existent déjà soit supprimés.
- **backup** \[_boolean_\]: Utilisez la valeur _true_ si vous voulez qu'une backup soit créée avant de supprimer les fichiers quand l'option `overwrite` est égale à _true_. Les fichiers de backup auront le nom suivant : `your_file.php.bak`
- **interface** \[_boolean_\]: Utilisez la valeur _true_ si vous voulez générer des squelettes de tests pour les interfaces PHP.
- **private** \[_boolean_\]: Utilisez la valeur _true_ si vous voulez générer des squelettes de tests pour les méthodes privées ou protégées.
- **auto** \[_boolean_\]: Utilisez la valeur _true_ si vous voulez générer automatiquement les tests unitaires des méthodes `getter` / `setter`, ou les instanciations des classes et des traits.
- **ignore** \[_boolean_\]: Utilisez la valeur _true_ si vous voulez utilisez les erreurs peu importantes (fichier impossible à analyser dans un dossier ...).
- **exclude** \[_string_ ou _null_\]: Un expression régulière PHP pour les fichiers qui ne devraient pas être analysés. Utilisez _null_ en valeur si vous ne souhaitez pas filtrer les fichiers avec ce mode.   
   C'est une condition que les fichiers ne doivent pas remplir pour être analysés.
- **include** \[_string_ ou _null_\]: Un expression régulière PHP pour les fichiers qui doivent être analysés. Utilisez _null_ en valeur si vous ne souhaitez pas filtrer les fichiers avec ce mode.   
   C'est une condition que les fichiers doivent remplir pour être analysés.
- **dirs** \[_array_\]: Un tableau de dossiers `source: cible`. PhpUnitGen analysera chaque fichier du dossier source (et les sous-dossier), puis générera les fichiers de tests dans le dossier cible. La valeur _null_ permet de ne pas analyser de dossier.
- **files** \[_array_\]: Un tableau de fichiers `source: cible`. PhpUnitGen analysera chaque fichier source, puis générera les fichiers de tests cibles. La valeur _null_ permet de ne pas analyser de fichier.